</center></td></tr>
</table>
<!-- CONTENT end -->


<!-- FOOTER -->
<table class="template" border="0" cellpadding="0" cellspacing="0">
  <tr><td><center class="template-inner">

    <table cellpadding="0" cellspacing="0" class="table-content">
        <tbody><tr><td class="table-content-td">

          <p class="table-content-title with-respect">С уважением, коллектив интернет-магазина <?php print ucfirst(PNEVMOTEH_DOMAIN); ?></p>

          <p class="error-destination">Если это письмо попало к Вам по ошибке, пожалуйста, сообщите об этом по адресу: <?php print variable_get('site_mail',''); ?>.</p>


          <table cellpadding="0" cellspacing="0" class="table-clear">
            <tbody>
            <tr>
              <td class="table-footer-col-1">
                <a href="https://vk.com/pnevmoteh" target="_BLANK" rel="nofollow" class="footer-social vk"></a>
                <a href="https://www.facebook.com/pnevmoteh/" target="_BLANK" rel="nofollow" class="footer-social fb"></a>
                <a href="https://www.youtube.com/channel/UCEbXENX4MdIQBacjiWKsijw" target="_BLANK" rel="nofollow" class="footer-social yt"></a>
              </td>
              <td class="table-footer-col-2">
                <a href="http://clck.yandex.ru/redir/dtype=stred/pid=47/cid=1248/*https://market.yandex.ru/shop/171702/reviews/add" ><img src="<?php print pt_path_to_theme(); ?>/images/pnevmo/img/informer.png" border="0" alt="Оцените качество магазина на Яндекс.Маркете.">
                </a>
              </td>
              <td class="table-footer-col-3">
                <p class="footer-rights"><?php print variable_get('site_name',''); ?>.<br>Реализация строительного оборудования.</p>
              </td>
            </tr>
            </tbody>
          </table>
            </td></tr></tbody>
    </table>
    <p style="height: 50px; margin: 0;">&#xA0;</p>

  </center></td></tr>
</table>
<!-- FOOTER end -->

</div><!--.style-parser-->

</body>
</html>